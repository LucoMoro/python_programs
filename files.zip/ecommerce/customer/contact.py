def contact_costumer():
    print("contact_costumer")